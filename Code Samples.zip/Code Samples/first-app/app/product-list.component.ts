import { Component, OnInit } from '@angular/core';
import {Product} from './product.model';
import {MyProductService} from './my-product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  searchKey:string;
  filteredProducts:any;

  
  products: any;

  

  constructor(private service:MyProductService){
    
      service.getAllProducts().subscribe(data =>{
    
        this.products = data;
    
      }
      )
    
    
    }
    
  

  ngOnInit(): void {
  }


  search():void{
    
      console.log("inside search")
      this.filteredProducts= this.products.filter(p => p.name==this.searchKey);
    
    }
    


}
