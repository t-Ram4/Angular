import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import {Product} from './product.model';


@Injectable({
  providedIn: 'root'
})
export class MyProductService {

  constructor(private httpClient:HttpClient){
    
  } 

  getAllProducts(){
    console.log("inside service method");
    return this.httpClient.get('http://localhost:3000/products');
  
  }
 
  
  createProduct(product:Product){
    
    return this.httpClient.post('http://localhost:3000/products',product,{
  
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
     
      }
      )
  
    });
  }

  updateProduct(productId,updatedResource){
    
      const endpointurl = 'http://localhost:3000/products';
    
      return this.httpClient.put(`${endpointurl}/${productId}`,updatedResource,{
        
            headers: new HttpHeaders({
              'Content-Type': 'application/json'
           
            }
            )
        
          });
    
    }

    deleteProduct(productId){
      
        const endpointurl = 'http://localhost:3000/products';
        
          return this.httpClient.delete(`${endpointurl}/${productId}`);
      
      }
      
  

}
