import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import { ViewCustomerComponent } from './view-customer.component';
import { ViewProductComponent } from './view-product.component';
import { WelcomeComponent } from './welcome.component';
import { RouterModule } from '@angular/router';
import { ProductComponent } from './product.component';
import {ReactiveFormsModule} from '@angular/forms';
import { ReactiveProductComponent } from './reactive-product.component';
import { NestedProductComponent } from './nested-product.component';
import { FormbuilderProductComponent } from './formbuilder-product.component';
import { ValidationProductComponent } from './validation-product.component';
import { ProductListComponent } from './product-list.component';
import { ProductDetailsComponent } from './product-details.component';
import {EditProductComponent}  from './edit-product.component';
import { MyProductListComponent } from './my-product-list.component';
import { LoginComponent } from './login.component';
import {AuthGuardService} from './auth-guard.service';
import { MyProductComponent } from './my-product.component';


@NgModule({
  declarations: [
    AppComponent,
    ViewCustomerComponent,
    ViewProductComponent,
    WelcomeComponent,
    ProductComponent,
    ReactiveProductComponent,
    NestedProductComponent,
    FormbuilderProductComponent,
    ValidationProductComponent,
    ProductListComponent,
    ProductDetailsComponent,
    EditProductComponent,
    MyProductListComponent,
    LoginComponent,
    MyProductComponent
   
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule.forRoot(
      [
        {path:'login',component:LoginComponent},
        {path:'customer',component:ViewCustomerComponent},
        {path:'viewProduct',component:ViewProductComponent},
        {path:'home',component:WelcomeComponent},
        {path:'product',component:ProductComponent},
        {path:'reactiveProduct',component:ReactiveProductComponent},
        {path:'nestedProduct',component:NestedProductComponent},
        {path:'formBuilderProduct',component:FormbuilderProductComponent},
        {path:'validationProduct',component:ValidationProductComponent},
        {path:'productList',component:ProductListComponent},
        {path:'edit-product/:id',component:EditProductComponent},
        {path:'myProductList',component:MyProductListComponent},
        {path:'myProduct',component:MyProductComponent}
      ]
    )
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
