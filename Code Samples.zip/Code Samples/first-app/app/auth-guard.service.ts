import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Router } from '@angular/router';
import {AuthService} from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {

  constructor(private router:Router,private auth:AuthService) { }
  
    canActivate( route: ActivatedRouteSnapshot,state: RouterStateSnapshot):  boolean  {
        console.log("inside canactivate");
        console.log("loggedIn: "+this.auth.loggedIn);
      if(this.auth.loggedIn==true){ 
        console.log("inside if"); 
      return true;
      }
      else{
        console.log("else");
      this.router.navigate(['/login']);
      } 
    }
  



}
