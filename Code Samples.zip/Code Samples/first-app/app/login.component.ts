import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {AuthService} from './auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username:string;
  password:string;
  loggedIn:boolean;

  constructor(private router:Router,private auth:AuthService) { }

  ngOnInit(): void {
  }

login():void{

  console.log("user name: "+this.username);
  console.log("Password: "+this.password);

  if(this.username==='admin' && this.password==='password'){
    this.loggedIn = true;
    this.auth.login();
      this.router.navigate(['/reactiveProduct']);
  }

}



}
