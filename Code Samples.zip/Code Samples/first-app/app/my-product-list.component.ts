import { Component, OnInit } from '@angular/core';
import {Product} from './product.model';
import {ProductService} from './product.service'


@Component({
  selector: 'app-my-product-list',
  templateUrl: './my-product-list.component.html',
  styleUrls: ['./my-product-list.component.css']
})
export class MyProductListComponent implements OnInit {

  searchKey:string;
  filteredProducts:any;
  products: any;

  

  constructor(private service:ProductService){

  service.getAllProducts().subscribe(data =>{

    this.products = data;

  }
  )


}

  

  ngOnInit(): void {
  }

search():void{

  console.log("inside search")
  this.filteredProducts= this.products.filter(p => p.name==this.searchKey);

}

  
  }


