import { Component, OnInit } from '@angular/core';
import {Product} from './product.model';
import {FormGroup,FormControl} from '@angular/forms';



@Component({
  selector: 'app-nested-product',
  templateUrl: './nested-product.component.html',
  styleUrls: ['./nested-product.component.css']
})
export class NestedProductComponent implements OnInit {

  product = new Product(1,"Laptop",10);
  
    productForm:FormGroup;
  
    constructor() { }
  
    ngOnInit(): void {
  
      this.productForm = new FormGroup({
  
        id: new FormControl(this.product.id),
        name:new FormControl(this.product.name),
        quantity:new FormControl(this.product.quantity),

        brand:new FormGroup({

            brandName:new FormControl(),
            warrantyInYears:new FormControl(),
            rating:new FormControl()


        })
  
      }); 
  
    }
  
    saveForm():void{
      
      console.log(this.productForm.value);
      
    }


}
