import { Component, OnInit } from '@angular/core';
import {Product} from './product.model';
import {MyProductService} from './my-product.service';


@Component({
  selector: 'app-my-product',
  templateUrl: './my-product.component.html',
  styleUrls: ['./my-product.component.css']
})
export class MyProductComponent implements OnInit {

  product = new Product(1,"Laptop",10);
  

isSaved:boolean;

isUpdated:boolean;

isDeleted:boolean;

  constructor(private service:MyProductService){}
  

  ngOnInit(): void {
  }

  saveForm(product:Product):void{   
    
   this.service.createProduct(product).subscribe(data =>{
      
          this.isSaved =  true;
      
        }
        );
    
  }

  updateProduct(productId){
    const updatedForm = {id:productId,name:'Bicycle',quantity:20};
  
    this.service.updateProduct(productId,updatedForm).subscribe(data =>{
      
          this.isUpdated=true;
      
        }
        );
  
  }
  

  deleteProduct(productId){
    
  
    this.service.deleteProduct(productId).subscribe(data =>{
      
          this.isDeleted=true;
      
        }
        );
  
  }
  
  


}
