import { Component } from '@angular/core';
import {ProductService} from './product.service';
import {AuthService} from './auth.service';
import {MyProductService} from './my-product.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[ProductService,AuthService,MyProductService]
  
})
export class AppComponent {
  title = 'first-app';

  name:string="Ram";


display():void{

  console.log("button is clicked");
}

}
