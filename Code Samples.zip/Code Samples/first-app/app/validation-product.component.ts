import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,FormBuilder,Validators} from '@angular/forms';

@Component({
  selector: 'app-validation-product',
  templateUrl: './validation-product.component.html',
  styleUrls: ['./validation-product.component.css']
})
export class ValidationProductComponent implements OnInit {

  productForm:FormGroup;
  
    constructor(private fb:FormBuilder) { }
  
    ngOnInit(): void {
  
      this.productForm = this.fb.group({
  
        id: [''],
        name:['',Validators.required],
        quantity:['']
  
      }); 
  
    }
  
    saveForm():void{
      
      console.log(this.productForm.value);
      
    }

}
