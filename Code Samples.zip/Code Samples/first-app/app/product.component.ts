import { Component, OnInit } from '@angular/core';
import {Product} from './product.model';
import {ProductService} from './product.service';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  product = new Product(1,"Laptop",10);

  product1:any;

  isUpdated:boolean;

  isDeleted:boolean;

  constructor(private service:ProductService){}

  ngOnInit(): void {
  }


  saveForm(product:Product):void{   
    
  // const newFormData = {id:5,name:'Grinder',quantity:20}
  //const newFormData = {id:product.id,name:product.name,quantity:product.quantity};
    this.service.createProduct(product).subscribe(data =>{
      
          this.product1 = data;
      
        }
        );
    
  }

updateProduct(productId){
  const updatedForm = {id:productId,name:'Air cooler',quantity:20};

  this.service.updateProduct(productId,updatedForm).subscribe(data =>{
    
        this.isUpdated=true;
    
      }
      );

}

deleteProduct(productId){
  

  this.service.deleteProduct(productId).subscribe(data =>{
    
        this.isDeleted=true;
    
      }
      );

}



}
