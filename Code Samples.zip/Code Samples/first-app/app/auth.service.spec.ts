import { TestBed } from '@angular/core/testing';

import { AuthService } from './auth.service';

fdescribe('AuthService', () => {
  let service: AuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthService);
  });

  it('test login method', () => {
    console.log('inside test case for login method')
    service.login();
    expect(service.isLoggedIn()).toBeTrue;
  });
  it('test addition', () => {
    var i=10;
    var k = 20;
    expect(i+k).toBe(30);
  });
});
