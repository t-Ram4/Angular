import { Component, OnInit } from '@angular/core';
import {Product} from './product.model';
import {FormGroup,FormControl,FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-formbuilder-product',
  templateUrl: './formbuilder-product.component.html',
  styleUrls: ['./formbuilder-product.component.css']
})
export class FormbuilderProductComponent implements OnInit {
  

  product = new Product(1,"Laptop",10);
  
    productForm:FormGroup;
  
    constructor(private fb:FormBuilder) { }
  
    ngOnInit(): void {
  
      this.productForm = this.fb.group({
  
        id: [this.product.id],
        name:[this.product.name],
        quantity:[this.product.quantity]
  
      }); 
  
    }
  
    saveForm():void{
      
      console.log(this.productForm.value);
      
    }


}
