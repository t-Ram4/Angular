import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ValidatorProductComponent } from './validator-product.component';

describe('ValidatorProductComponent', () => {
  let component: ValidatorProductComponent;
  let fixture: ComponentFixture<ValidatorProductComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ValidatorProductComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ValidatorProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
