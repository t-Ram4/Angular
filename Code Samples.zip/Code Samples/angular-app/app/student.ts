import { Department } from "./department";

export interface Student {
    name: string;
    id: number;
    dept:Department
  }