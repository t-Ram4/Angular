import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-customer',
  templateUrl: './view-customer.component.html',
  styleUrls: ['./view-customer.component.scss']
})
export class ViewCustomerComponent implements OnInit {

       id:number=100;
       name:string="James";


  constructor() { }

  ngOnInit(): void {
  }

  display():void{

    console.log("button clicked")
  }

}
