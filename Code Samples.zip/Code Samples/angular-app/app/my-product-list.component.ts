import { Component, OnInit } from '@angular/core';
import {Product} from './product.model';
import {ProductService} from './product.service'


@Component({
  selector: 'app-my-product-list',
  templateUrl: './my-product-list.component.html',
  styleUrls: ['./my-product-list.component.scss']
})
export class MyProductListComponent implements OnInit {

  searchKey:string;
  filteredProducts:any;
  products: any[];

  

  constructor(private service:ProductService){
  this.products = service.getAllProducts();
}

  

  ngOnInit(): void {
  }

search():void{

  console.log("inside search")
  this.filteredProducts= this.products.filter(p => p.name==this.searchKey);

}

}
