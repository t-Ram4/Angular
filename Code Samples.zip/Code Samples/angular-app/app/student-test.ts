import { Student } from "./student";

let deptObj:Student["dept"]={

    name:"Electrical",
    id:100
    
    
    

}

console.log(deptObj);