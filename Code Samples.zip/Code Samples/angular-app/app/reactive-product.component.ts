import { Component, OnInit } from '@angular/core';
import {Product} from './product.model';
import {FormGroup,FormControl} from '@angular/forms';


@Component({
  selector: 'app-reactive-product',
  templateUrl: './reactive-product.component.html',
  styleUrls: ['./reactive-product.component.scss']
})
export class ReactiveProductComponent implements OnInit {

  product = new Product(10,"Laptop",10);

  productForm:FormGroup;

  constructor() { }

  ngOnInit(): void {

    this.productForm = new FormGroup({

      id: new FormControl(this.product.id),
      name:new FormControl(this.product.name),
      quantity:new FormControl(this.product.quantity)

    }); 

  }

  saveForm():void{
    
    console.log(this.productForm.value);
    
  }
}
