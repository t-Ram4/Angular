import { Component, OnInit } from '@angular/core';
import {Product} from './product.model';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {

  searchKey:string;
  filteredProducts:any;
  products: any[];

  product1 = new Product(1,"TV",10);
  product2 = new Product(2,"Laptop",15);

  constructor(){
this.products = [ 
  {id:1,name:'TV',quantity:10},
  {id:2,name:'Laptop',quantity:5},
  {id:3,name:'Mobile phone',quantity:10},
  {id:4,name:'Wahing machine',quantity:15},
  {id:5,name:'Airconditioner',quantity:20}

];
}

  

  ngOnInit(): void {
  }

search():void{

  console.log("inside search")
  this.filteredProducts= this.products.filter(p => p.name==this.searchKey);

}


}
