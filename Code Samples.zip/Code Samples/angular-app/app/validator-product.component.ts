import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,FormBuilder,Validators} from '@angular/forms';

@Component({
  selector: 'app-validator-product',
  templateUrl: './validator-product.component.html',
  styleUrls: ['./validator-product.component.scss']
})
export class ValidatorProductComponent implements OnInit {

  productForm:FormGroup;
  
    constructor(private fb:FormBuilder) { }
  
    ngOnInit(): void {
  
      this.productForm = this.fb.group({
  
        id: [''],
        name:['',Validators.required],
        quantity:['']
  
      }); 
  
    }
  
    saveForm():void{
      
      console.log(this.productForm.value);
      
    }
}
