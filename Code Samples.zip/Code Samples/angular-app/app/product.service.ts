import { Injectable } from '@angular/core';
import {Product} from './product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  products:Product[];
  

  constructor(){
    this.products = [ 
      {id:1,name:'TV',quantity:10},
      {id:2,name:'Laptop',quantity:5},
      {id:3,name:'Mobile phone',quantity:10},
      {id:4,name:'Wahing machine',quantity:15},
      {id:5,name:'Airconditioner',quantity:20}
    
    ];

  }

getAllProducts():Product[]{
  console.log("inside service method");
  return this.products;

}





}
