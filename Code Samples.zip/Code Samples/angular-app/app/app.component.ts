import { Component } from '@angular/core';
import { Customer } from "./customer";
import {ProductService} from './product.service';
import {AuthService} from './auth.service';
import {AuthGuardService} from './auth-guard.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers:[ProductService,AuthService,AuthGuardService]
})
export class AppComponent {
  title = 'angular-app';
  myGreeting = 'Welcome';
  cust:Customer = {name:"Ram",id:100};
  isValid = true;

  skills = ["Java","SQL","C","Python"];
  

}
