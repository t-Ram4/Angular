import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ViewCustomerComponent } from './view-customer.component';
import { EditCustomerComponent } from './edit-customer.component';
import { RouterModule } from '@angular/router';
import { ProductComponent } from './product.component';
import {FormsModule} from '@angular/forms';
import {ReactiveFormsModule} from '@angular/forms';
import { ReactiveProductComponent } from './reactive-product.component';
import { NestedProductComponent } from './nested-product.component';
import { FormbuilderProductComponent } from './formbuilder-product.component';
import { ValidatorProductComponent } from './validator-product.component';
import { ProductListComponent } from './product-list.component';
import { ProductDetailsComponent } from './product-details.component';
import { EditProductComponent } from './edit-product.component';
import { MyProductListComponent } from './my-product-list.component';
import { LoginComponent } from './login.component';
import {AuthGuardService} from './auth-guard.service';

@NgModule({
  declarations: [
    AppComponent,
    ViewCustomerComponent,
    EditCustomerComponent,
    ProductComponent,
    ReactiveProductComponent,
    NestedProductComponent,
    FormbuilderProductComponent,
    ValidatorProductComponent,
    ProductListComponent,
    ProductDetailsComponent,
    EditProductComponent,
    MyProductListComponent,
    LoginComponent    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(
      [
        {path:'login',component:LoginComponent},
        {path:'view',component:ViewCustomerComponent},
        {path:'edit',component:EditCustomerComponent},
        {path:'product',component:ProductComponent},
        {path:'reactiveProduct',canActivate:[AuthGuardService],  component:ReactiveProductComponent},
        {path:'nestedProduct',component:NestedProductComponent},
        {path:'formBuilderProduct',component:FormbuilderProductComponent},
        {path:'validatorProduct',component:ValidatorProductComponent},
        {path:'productList',component:ProductListComponent},
        {path:'edit-product/:id',component:EditProductComponent},
        {path:'my-productList',component:MyProductListComponent}
      ]
    ),
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
